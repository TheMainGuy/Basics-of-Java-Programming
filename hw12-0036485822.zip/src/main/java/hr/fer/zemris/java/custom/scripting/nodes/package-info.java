/**
 * This package contains classes which represent parser nodes.
 * 
 */
/**
 * @author tin
 *
 */
package hr.fer.zemris.java.custom.scripting.nodes;