package hr.fer.zemris.java.custom.scripting.elems;

/**
 * Class represents a single tag element.
 * 
 * @author tin
 *
 */
public class Element {
  
  /**
   * Method which returns this element as text.
   * Not implemented here.
   * 
   * @return
   */
  public String asText() {
    return "";
  }
}
