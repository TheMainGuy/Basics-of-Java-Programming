package hr.fer.zemris.java.custom.collections;

/**
 * Class which currently doesn't do anything.
 * 
 * @author tin
 *
 */
public class Processor {
  /**
   * Method which processes. Not implemented yet.
   * 
   * @param value object to be processed
   */
  public void process(Object value) {

  }

}
