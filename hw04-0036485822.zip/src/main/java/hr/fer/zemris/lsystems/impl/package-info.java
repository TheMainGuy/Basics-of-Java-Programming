/**
 * Package contains classes needed for LSystems implementation in 4th OPJJ homework.
 * 
 */
/**
 * @author tin
 *
 */
package hr.fer.zemris.lsystems.impl;