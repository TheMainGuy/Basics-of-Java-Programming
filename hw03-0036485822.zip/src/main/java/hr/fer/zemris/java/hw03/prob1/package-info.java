/**
 * In this package are java files for solving first problem in OPJJ homework 3.
 */
/**
 * 
 * @author tin
 *
 */
package hr.fer.zemris.java.hw03.prob1;