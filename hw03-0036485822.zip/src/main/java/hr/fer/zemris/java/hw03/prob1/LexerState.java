package hr.fer.zemris.java.hw03.prob1;

/**
 * Possible lexer states.
 * 
 * @author tin
 *
 */
public enum LexerState {
  BASIC, EXTENDED
}
