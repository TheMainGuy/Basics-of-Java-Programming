/**
 * This package contains classes which represent tag elements for parser to use while parsing documents.
 */
/**
 * @author tin
 *
 */
package hr.fer.zemris.java.custom.scripting.elems;