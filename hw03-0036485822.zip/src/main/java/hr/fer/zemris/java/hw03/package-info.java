/**
 * This package contains script tester.
 */
/**
 * @author tin
 *
 */
package hr.fer.zemris.java.hw03;