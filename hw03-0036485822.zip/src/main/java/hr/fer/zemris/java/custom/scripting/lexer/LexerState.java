package hr.fer.zemris.java.custom.scripting.lexer;

/**
 * Possible lexer states.
 * 
 * @author tin
 *
 */
public enum LexerState {
  TEXT, TAG
}
