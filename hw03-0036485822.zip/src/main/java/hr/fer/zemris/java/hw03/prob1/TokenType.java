package hr.fer.zemris.java.hw03.prob1;

/**
 * Represents lexer token types.
 * 
 * @author tin
 *
 */
public enum TokenType {
  EOF, WORD, NUMBER, SYMBOL
}
