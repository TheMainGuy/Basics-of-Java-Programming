/**
 * This package contains collection classes to ease solving 3rd homework problems. 
 * Classes are copied from 2nd homework.
 */
/**
 * @author tin
 * @version 1.0
 */
package hr.fer.zemris.java.custom.collections;