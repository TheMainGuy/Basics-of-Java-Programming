/**
 * This package contains script parser and its dependency exception.
 * 
 */
/**
 * @author tin
 *
 */
package hr.fer.zemris.java.custom.scripting.parser;